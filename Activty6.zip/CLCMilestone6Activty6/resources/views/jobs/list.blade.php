<?php 

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 7th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

// This page is for the admins only where they can make other users admins.
?>

@extends('layouts.app')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
@section('content')

<div class="card card-default">
	
	<div class="card-header">Jobs</div>
	
	
	<div class="card-body">
	
		@if($jobs->count() > 0)
		
			<table class="table">
			
				<thead>
				
					<th>#</th>
					
					<th>Job Title</th>
					
					<th>Company Name</th>
					
					<th>Job Description</th>
					
					<th>Job Location</th>
					
					<th>Employment Type</th>
					
					</thead>
					
					<tbody>
					
						@foreach($jobs as $job)
						
					    	<tr>
					    	
					    		<td>
										{{ $job->id }}
						    </td>
						    
						    <td>
						    
						    {{ $job->jobTitle }}
						    
						    </td>
						    
						    <td>
						    
						    {{ $job->companyName }}
						    
						    </td>
						    
						    <td>
						    
						    {{ $job->jobDescription }}
						    
						    </td>
						    
						    <td>  
						    	
						    {{ $job->jobLocation }}
						    
						    </td>
						    
						    <td>  
						    	
						    {{ $job->employmentType }}
						    
						    </td>
						    	<td>
						    
						    <form method="POST" action="{{ route('apply', [$job->id]) }}">
                                {{ csrf_field() }}
                                <button type="submit" class="btn btn-success btn-sn">Apply</button>
                            </form>	
						    	
						    	<td>
						    	
						    </td>
						    	
						    </td>
						    
						    </tr>
						    
						 @endforeach						 
					
					</tbody>			
			
			</table>
			
		@else
			
			<h3 class="text-center">No Jobs Yet</h3>
			
		@endif
		
	</div>
	
</div>

@endsection
			