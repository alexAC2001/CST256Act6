<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Services\Data\Utility\DBConnect;
//use App\Models\UserModel;
use App\Services\Business\SecurityService;
use App\Models\DTO;

class JobsRestController extends Controller
{    
    private $dto;
    private $ss;  

    // This method will return all jobs in the database
    public function index()
    {
        // Calling the method
        $ss = new SecurityService();
        print_r($ss->getAllJobs());
        // DTO stuff
        $d = new DTO("Success123", "Returned all jobs", "Success!");
        $d2 = new DTO("Error201", "There are no jobs in the database", "Failure!");
        if($ss->getAllJobs() == true)
        {
            echo json_encode($d); // Retrieve the messages in json format
        }
        else
        {
            return json_encode($d2); // Retrieve error messages
        }
    }
    
    // This method will show one desired job
    public function show($id)
    {
        // Calling the method
        $ss = new SecurityService();

        // DTO stuff
        $d = new DTO("Success123", "Located Job", "Success!");
        $d2 = new DTO("Error247", "Could not find job", "Failure!");
        if($ss->getJob($id) == true)
        {
            echo json_encode($d);// Retrieve the messages in json format
        }
        else 
        {
            return json_encode($d2);// Retrieve error messages
        }
    }
    
    // This method will show one desired member profile
    public function showMember($id)
    {
        // Calling the method
        $ss = new SecurityService();
        
        // DTO stuff
        $d = new DTO("Success456", "Located Member Profile", "Success!");
        $d2 = new DTO("Error256", "Could not find profile", "Failure!");
        if($ss->getMember($id))
        {
            echo json_encode($d); // Retrieve the messages in json format
        }
        else 
        {
            return json_encode($d2);// Retrieve error messages
        }
    }

}