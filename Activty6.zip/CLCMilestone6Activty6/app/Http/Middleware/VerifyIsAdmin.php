<?php

namespace App\Http\Middleware;

use Illuminate\Support\Facades\Log;
use Closure;

class VerifyIsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    
    // If the user is not an admin, they should not visit the page
    public function handle($request, Closure $next)
    {
        
        if(!auth()->user()->isAdmin())
        {
            Log::info("Entering the My Middleware in handle ()");
            return redirect(route('home'));
        }
        
        return $next($request);
    }
}
