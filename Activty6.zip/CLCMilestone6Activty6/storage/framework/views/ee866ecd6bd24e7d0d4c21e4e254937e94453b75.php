<html>
	<input type="file" name="image">
</html><?php /**PATH C:\MAMP\htdocs\CLCMilestone6Activty6\resources\views/layouts/image.blade.php ENDPATH**/ ?>