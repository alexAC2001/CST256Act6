<?php 

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 7th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44




// This page is for the admins only where they can make other users admins.
?>


<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('groups.create')); ?>">
	Post New Affinity Group
</a>
<div class="card card-default">
	
	<div class="card-header">Affinity Groups</div>
	
	
	<div class="card-body">
	
		<?php if($groups->count() > 0): ?>
		
			<table class="table">
			
				<thead>
				
					<th>#</th>
					
					<th>Group Title</th>
					
					<th>About</th>
					
					<th>Rules</th>
					
					<th>Members</th>
					
					<th>Actions</th>
					
					</thead>
					
					<tbody>
					
						<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
					    	<tr>
					    	
					    	<td>
							<?php echo e($group->id); ?>

						    </td>
						    
						    <td>
						    
						    <?php echo e($group->groupTitle); ?>

						    
						    </td>
						    
						    <td>
						    
						    <?php echo e($group->about); ?>

						    
						    </td>
						    
						    <td>  
						    	
						    <?php echo e($group->rules); ?>

						    
						    </td>
						    
						    <td>  
						    	
						    <?php echo e($group->members); ?>

						    
						    </td>
						    
						    <td>
						    
							<form method="PUT" action="<?php echo e(route('groups.edit', [$group->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-success btn-sn">Update</button>
                            </form>	
						    	
						    	<td>
						    <form method="POST" action="<?php echo e(route('groups.destroy', [$group->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-success btn-sn">Delete</button>
                            </form>	
						    	
						    </td>
						    	
						    </td>
						    
						    </tr>
						    
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						 
					
					</tbody>			
			
			</table>
			
		<?php else: ?>
			
			<h3 class="text-center">No Groups Yet</h3>
			
		<?php endif; ?>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>
			
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\CLCMilestone6Activty6\resources\views/groups/index.blade.php ENDPATH**/ ?>